from django.db import models
from django import forms

class Note(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class NoteForm(forms.ModelForm):
    class Meta:
        model = Note
        fields = ['title', 'content']
